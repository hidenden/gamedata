# 標準ライブラリ
from datetime import datetime, timedelta, date
from typing import List, Callable

# サードパーティライブラリ
import pandas as pd
from pandas.io.formats.style import Styler
import polars as pl

# プロジェクト内モジュール
from . import hard_info as hi
from . import hard_sales as hs
from . import hard_sales_filter as hsf
from . import hard_sales_extract as hse

# Global variables
_styler_is_disabled: bool = False  # デフォルトではStylerは有効


def disable_styler(disable: bool = True):
    """
    スタイラーのモードを無効にする

    Args:
        disable: スタイラーを無効にするかどうか（デフォルト: True）。
    """
    global _styler_is_disabled
    _styler_is_disabled = disable


def rename_columns(df: pl.DataFrame) -> pl.DataFrame:
    """
    DataFrameの列名を日本語に変換する

    Args:
        df: 変換対象のDataFrame

    Returns:
        pl.DataFrame: 列名が日本語に変換されたDataFrame
    """
    base_rename_dict = {
        "full_name": "ハード",
        "hw": "ハード",
        "report_date": "集計日",
        "delta_week": "週差",
        "index_week": "週数",
        "sum_units": "累計台数",
        "units": "販売台数",
        "units_diff": "前週差",
        "maker_name": "メーカー",
        "monthly_units": "月間販売台数",
        "weekly_units": "週間販売台数",
        "yearly_units": "年間販売台数",
        "month": "月",
        "year": "年",
        "fiscal_year": "FY",
        "week": "週",
    }
    df = df.rename(base_rename_dict, strict=False)
    return df


def rename_hw(df: pl.DataFrame) -> pl.DataFrame:
    """
    DataFrameのhw列の値をフルネームに変換する

    Args:
        df: hw列を持つDataFrame

    Returns:
        pl.DataFrame: hw列がフルネームに変換されたDataFrame
    """
    # dfにカラム:hwがある場合、hw列の値をhard_dictで変換する
    if "hw" in df.columns:
        hard_dict = hi.get_hard_dict()
        df = df.with_columns(pl.col("hw").replace(hard_dict))
    return df


def units_by_date_hw_table(
    df: pl.DataFrame,
    begin: datetime | date | None = None,
    end: datetime | date | None = None,
) -> pd.io.formats.style.Styler:
    """
    日付とハード別の販売台数チャートを出力する

    Args:
        df: load_hard_sales()の戻り値のDataFrame

    Returns:
        pd.io.formats.style.Styler: スタイル適用済みのStylerオブジェクト

        Stylerの表示構成:
        - index: 集計日 (date), ハード (string): 日付とハード名のマルチインデックス
        - columns: 販売台数 (int64), 前週差 (int64), 累計台数 (int64), 週数 (int32)
    """
    # beginの1週間前の日付を得る

    begin_minus_one = begin - timedelta(days=7) if begin is not None else None
    df = hsf.date_filter(df, begin=begin_minus_one, end=end)
    df = hsf.date_filter(
        df, begin=begin, end=end
    )  # 再度日付フィルタを適用して、beginの1週間前のデータを除外
    df = df.sort(
        by=["report_date", "units", "hw"], descending=[False, True, False]
    ).select(
        pl.col("report_date"),
        pl.col("full_name"),
        pl.col("units"),
        pl.col("units_diff"),
        pl.col("sum_units"),
        pl.col("index_week"),
    )
    df = rename_columns(df)

    pdf = df.to_pandas()
    pdf = pdf.set_index(["集計日", "ハード"])
    styled = (
        pdf.style.format({"販売台数": "{:,}", "累計台数": "{:,}", "前週差": "{:+,}"})
        .set_properties(
            **{"text-align": "right"}, subset=["販売台数", "累計台数", "前週差"]
        )
        .format_index(lambda t: t.strftime("%Y-%m-%d"), level=0, axis=0)
        .bar(subset=["販売台数"], color="#18ba06")
    )
    styled = styled.set_table_attributes('class="sales-table"')
    return styled


def _build_periodic_ranking(
    rank_n: int = 10,
    begin: datetime | date | None = None,
    end: datetime | date | None = None,
    hw: List[str] = [],
    maker: List[str] = [],
    data_source_fn: Callable = hsf.monthly_sales,
    sort_column: str = "monthly_units",
    headers: List[str] = ["year", "month"],
) -> pl.DataFrame:
    """
    ある期間のランキングチャートを出力する共通関数

    Args:
        rank_n: 上位n件。マイナスの場合は下位n件
        begin: 集計開始日
        end: 集計終了日
        hw: ハード名リスト（指定時はハードモード）
        maker: メーカー名リスト（指定時はメーカーモード）
        data_source_fn: データソース関数（weekly_sales, monthly_sales, yearly_salesなど）
        sort_column: ソートに使用する列名
        headers: 出力に含めるヘッダー列のリスト

    Returns:
        pl.DataFrame: ランキングデータのDataFrame。

        DataFrameのカラム構成（headersとsort_columnにより変動）:
        - 週間: 順位, 集計日, ハード/メーカー, 週間販売台数
        - 月間: 順位, 年, 月, ハード/メーカー, 月間販売台数
        - 年間: 順位, 年, ハード/メーカー, 年間販売台数
    """
    df_all = hs.load_hard_sales()
    if (not hw) and maker:
        # This is maker mode
        maker_mode = True
        key_column = "maker_name"
        filter_dict = maker
    else:
        maker_mode = False
        key_column = "hw"
        if hw:
            filter_dict = hw
        else:
            filter_dict = None  # 全ハード対象

    if rank_n < 0:  # 負の数の場合は逆順ソート
        top_n = abs(rank_n)
        descending_flag = False
    else:  # 正の数の場合は通常ソート
        top_n = rank_n
        descending_flag = True

    df_src: pl.DataFrame = data_source_fn(
        df_all, begin=begin, end=end, maker_mode=maker_mode
    )

    df_src = df_src.filter(
        pl.col(key_column).is_in(filter_dict)
        if filter_dict is not None
        else pl.lit(True)
    ).sort(by=sort_column, descending=descending_flag)
    if len(df_src) > top_n:
        df_src = df_src.head(top_n)
    actual_rows = len(df_src)
    df_src = df_src.with_columns(
        順位=pl.arange(1, actual_rows + 1).cast(pl.Int16)
    ).select(["順位", *headers, key_column, sort_column])

    if not maker:
        df_src = rename_hw(df_src)
    df_src = rename_columns(df_src)
    return df_src


def weekly_sales_ranking(
    rank_n: int = 10,
    begin: datetime | date | None = None,
    end: datetime | date | None = None,
    hw: List[str] = [],
    maker: List[str] = [],
) -> pl.DataFrame:
    """
    週間ランキングチャートを出力する

    Args:
        rank_n: 上位n件。マイナスの場合は下位n件（デフォルト: 10）
        begin: 集計開始日
        end: 集計終了日
        hw: ハード名リスト（空の場合は全ハード）
        maker: メーカー名リスト（空の場合は全メーカー）

    Returns:
        pl.DataFrame: 週間ランキングのDataFrame

        DataFrameのカラム構成:
        - 順位 (Int16): 順位（1から開始）
        - 集計日 (Date): 集計期間の末日
        - ハード/メーカー (String): ハード名またはメーカー名
        - 週間販売台数 (Int64): 週次販売台数
    """
    return _build_periodic_ranking(
        rank_n=rank_n,
        begin=begin,
        end=end,
        hw=hw,
        maker=maker,
        data_source_fn=hsf.weekly_sales,
        sort_column="weekly_units",
        headers=["report_date"],
    )


def monthly_sales_ranking(
    rank_n: int = 10,
    begin: datetime | date | None = None,
    end: datetime | date | None = None,
    hw: List[str] = [],
    maker: List[str] = [],
) -> pl.DataFrame:
    """
    月間ランキングチャートを出力する

    Args:
        rank_n: 上位n件。マイナスの場合は下位n件（デフォルト: 10）
        begin: 集計開始日
        end: 集計終了日
        hw: ハード名リスト（空の場合は全ハード）
        maker: メーカー名リスト（空の場合は全メーカー）

    Returns:
        pl.DataFrame: 月間ランキングのDataFrame

        DataFrameのカラム構成:
        - 順位 (Int16): 順位（1から開始）
        - 年 (Int16): report_dateの年
        - 月 (Int16): report_dateの月
        - ハード/メーカー (String): ハード名またはメーカー名
        - 月間販売台数 (Int64): 月次販売台数
    """
    return _build_periodic_ranking(
        rank_n=rank_n,
        begin=begin,
        end=end,
        hw=hw,
        maker=maker,
        data_source_fn=hsf.monthly_sales,
        sort_column="monthly_units",
        headers=["year", "month"],
    )


def yearly_sales_ranking(
    rank_n: int = 10,
    begin: datetime | date | None = None,
    end: datetime | date | None = None,
    hw: List[str] = [],
    maker: List[str] = [],
) -> pl.DataFrame:
    """
    年間ランキングチャートを出力する

    Args:
        rank_n: 上位n件。マイナスの場合は下位n件（デフォルト: 10）
        begin: 集計開始日
        end: 集計終了日
        hw: ハード名リスト（空の場合は全ハード）
        maker: メーカー名リスト（空の場合は全メーカー）

    Returns:
        pl.DataFrame: 年間ランキングのDataFrame

        DataFrameのカラム構成:
        - 順位 (Int16): 順位（1から開始）
        - 年 (Int16): report_dateの年
        - ハード/メーカー (String): ハード名またはメーカー名
        - 年間販売台数 (Int64): 年次販売台数
    """
    return _build_periodic_ranking(
        rank_n=rank_n,
        begin=begin,
        end=end,
        hw=hw,
        maker=maker,
        data_source_fn=hsf.yearly_sales,
        sort_column="yearly_units",
        headers=["year"],
    )


def delta_week_ranking(delta_week: int) -> pl.DataFrame:
    """
    指定された発売後の経過週数での累計販売台数ランキングを出力する

    Args:
        delta_week: 発売日から何週間後か

    Returns:
        pl.DataFrame: 経過週数時点での累計販売台数ランキングのDataFrame

        DataFrameのカラム構成:
        - 順位 (Int16): 順位（1から開始）
        - 集計日 (Date): 集計期間の末日
        - 週差 (Int32): 発売日からの経過週数
        - ハード (String): ゲームハードの正式名称
        - 累計台数 (Int64): 累計販売台数
    """

    df = hs.load_hard_sales()

    df = df.filter(pl.col("delta_week") == delta_week).sort(
        by="sum_units", descending=True
    )
    row_num = len(df)
    df = df.with_columns(
        順位=pl.arange(1, row_num + 1).cast(pl.Int16)
    ).select(  # 通番のカラムを追加
        ["順位", "report_date", "delta_week", "full_name", "sum_units"]
    )
    return rename_columns(df)


def reached_unit_summary(n: int, all: bool = False) -> pl.DataFrame:
    df = hs.load_hard_sales()
    df = hse.extract_week_reached_units(df, n).sort(
        ["delta_week", "sum_units"], descending=[False, True]
    )
    if not all:
        df = df.head(10)

    df = df.select(["hw", "report_date", "index_week", "sum_units"])
    return df


def style_sales(
    df: pl.DataFrame,
    columns: List[str] | None = None,
    date_columns: List[str] | None = None,
    percent_columns: List[str] | None = None,
    datetime_index: bool = False,
    highlights: List[str] | None = None,
    gradients: List[str] | None = None,
    gradient_horizontal: bool = False,
    bars: List[str] | None = None,
    bar_color: str = "#18ba06dd",
) -> Styler | pl.DataFrame:
    """
    販売台数データフレームにスタイルを適用する

    Args:
        df: 販売台数データフレーム
        columns: スタイルを適用する列名のリスト（Noneの場合は全列）
        date_columns: 日付フォーマットを適用する列名のリスト
        percent_columns: パーセントフォーマットを適用する列名のリスト
        datetime_index: インデックスがdatetime型の場合に日付フォーマットを適用するかどうか(level=0のみ対応)
        highlights: 強調表示する列名のリスト
        gradients: グラデーションを適用する列名のリスト
        gradient_horizontal: 行方向にグラデーションを適用するかどうか
        bars: 棒グラフを適用する列名のリスト
        bar_color: 棒グラフの色（デフォルト: "#5fba7d"）

    Returns:
        Styler|pl.DataFrame: スタイルが適用されたStylerオブジェクトまたはDataFrame
    """
    global _styler_is_disabled
    if _styler_is_disabled:
        return df

    first_column = df.columns[0]
    pd_df = df.to_pandas()
    pd_df = pd_df.set_index(first_column)

    styled = pd_df.style
    if columns is None:
        columns = pd_df.columns.tolist()
    styled = styled.format("{:,.0f}", subset=columns)
    styled = styled.set_properties(**{"text-align": "right"}, subset=columns)

    if date_columns is not None:
        styled = styled.format(
            subset=date_columns, formatter=lambda t: t.strftime("%Y-%m-%d")
        )
        styled = styled.set_properties(**{"text-align": "left"}, subset=date_columns)

    if percent_columns is not None:
        styled = styled.format(subset=percent_columns, formatter="{:.1%}")
        styled = styled.set_properties(
            **{"text-align": "right"}, subset=percent_columns
        )

    if highlights is not None:
        for highlight in highlights:
            if highlight in columns:
                styled = styled.highlight_max(subset=[highlight], color="#b31d15")

    if gradients is not None:
        for gradient in gradients:
            if gradient in columns:
                styled = styled.background_gradient(subset=[gradient], cmap="Blues")

    if gradient_horizontal:
        styled = styled.background_gradient(axis=1, cmap="Blues")

    if bars is not None:
        for bar in bars:
            if bar in columns:
                styled = styled.bar(subset=[bar], color=bar_color)

    if datetime_index:
        styled = styled.format_index(lambda t: t.strftime("%Y-%m-%d"), axis=0, level=0)

    styled = styled.set_table_attributes('class="sales-table"')
    return styled


def style_df(
    df: pl.DataFrame,
    highlight: bool = False,
    gradient: bool = False,
    bar: bool = False,
    gradient_horizontal: bool = False,
    bar_color: str = "#18ba06dd",
) -> Styler | pl.DataFrame:
    """
    DataFrameをPandasのStylerオブジェクトに変換する

    Args:
        df: 変換対象のDataFrame
        highlight: 数値列を自動的に強調表示するかどうか
        gradient: 数値列に自動的にグラデーションを適用するかどうか
        bar: 数値列に自動的に棒グラフを適用するかどうか
        gradient_horizontal: 行方向にグラデーションを適用するかどうか
        bar_color: 棒グラフの色
    Returns:
        Styler|pl.DataFrame: 変換されたStylerオブジェクトまたはDataFrame
    """
    global _styler_is_disabled
    if _styler_is_disabled:
        return df

    # df.columns[0]の値がユニークかどうかを確認する｡ユニークはないなら､行番号のカラムを一番左側に追加する
    first_column = df.columns[0]
    all_columns = df.columns
    if df[first_column].n_unique() != df.height:
        df = df.with_columns(id=pl.arange(0, df.height).cast(pl.Int32)).select(
            ["id"] + all_columns
        )

    num_columns = df.select(pl.col(pl.Int64)).columns
    highlights = num_columns if highlight else None
    gradients = num_columns if gradient or gradient_horizontal else None
    bars = num_columns if bar else None

    date_columns = df.select(pl.col(pl.Date)).columns
    percent_columns = df.select(pl.col(pl.Float64)).columns

    # date_columns[0]とdf.columns[0]が同じ場合、date_columnsから削除する
    if date_columns and (date_columns[0] == df.columns[0]):
        date_columns = date_columns[1:]
        datetime_index = True
    else:
        datetime_index = False

    return style_sales(
        df,
        columns=num_columns,
        date_columns=date_columns,
        percent_columns=percent_columns,
        datetime_index=datetime_index,
        highlights=highlights,
        gradients=gradients,
        gradient_horizontal=gradient_horizontal,
        bars=bars,
        bar_color=bar_color,
    )
